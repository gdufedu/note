﻿=== Remove  Open Sans font Link from WP core ===
Contributors: suifengtec
Donate link:http://suoling.net/remove-open-sans-font-from-wp-core/
Tags: open sans, google fonts
Requires at least: 3.3
Tested up to: 3.8.1
Stable tag: 1.1.0
License:GPLv2 or later

Installs Remove  Open Sans font Link from WP core plugin on your wordpress blog so it will doesn't load Open Sans font from Google fonts.

== Description ==

Installs 'Remove  Open Sans font Link from WP core' plugin on your wordpress blog, so it will doesn't load Open Sans font from Google fonts.

== Installation ==

* Use WordPress’ builtin plugin installation system located in your WordPress admin panel, labeled as the "Add New" options in the "Plugins" menu to upload the zip file you downloaded
* Extract the zip file and upload the resulting "ink" folder on your server under `wp-content/plugins/`.

All you need to do after that is navigate to your blog’s administration panel, go in the plugins section and enable No Open Sans font from Google fonts.


For more information, see the ["Installing Plugins" article on the WordPress Codex](http://codex.wordpress.org/Managing_Plugins#Installing_Plugins).

== Frequently Asked Questions ==
throw a message on:http://suoling.net/remove-open-sans-font-from-wp-core/
= Any technical requirements? =

throw a message on:http://suoling.net/remove-open-sans-font-from-wp-core/
== Upgrade Notice ==
* 1.0.0 Initial release
== ChangeLog ==

= 1.0.0 =
* Initial release
= 1.1.0 =
* Remove open sans load for wordpress admin pages.
== Screenshots ==

Don't need UI!